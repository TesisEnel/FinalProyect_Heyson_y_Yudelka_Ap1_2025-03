﻿namespace FinalProyect.Models;
public enum ProcessType
{
    DerechoEnterramiento = 1,
    ArrendamientoTerreno = 2,
    DerechoConstruccion = 3,
    ExpedicionCertificacion = 4,
    RegistroDocumentacion = 5
}
