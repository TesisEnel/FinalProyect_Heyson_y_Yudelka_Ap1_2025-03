﻿namespace FinalProyect.Models;

public enum DocumentType
{
    CedulaSolicitante = 1,
    CedulaFallecido = 2,
    ActaDefuncion = 3,
    ReciboInspector= 4,
    ReciboColegioNotarios = 5,
    FotoReciboSellado = 6,
    Otro = 7
}
